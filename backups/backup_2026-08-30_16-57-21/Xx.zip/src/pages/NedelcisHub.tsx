import { useEffect, useMemo, useState, memo } from 'react';
import { DashboardLayout } from '@/components/DashboardLayout';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import {
  Plus, Pencil, Trash2, Settings as SettingsIcon, Calendar,
  Clock, Link as LinkIcon, GraduationCap, BookOpen, FileText, Users, Globe,
  Mail, Phone, Video, Image as ImageIcon, Music, Star, Heart, Sparkles,
  Award, Megaphone, Library, Briefcase, MapPin, Shield, Bell, Zap, ArrowUpRight,
  LogIn, Lock, Hourglass, CheckCircle2, XCircle,
} from 'lucide-react';
import { Link } from 'react-router-dom';

const ICON_MAP: Record<string, any> = {
  Link: LinkIcon, Globe, GraduationCap, BookOpen, FileText, Users, Mail, Phone,
  Video, Image: ImageIcon, Music, Star, Heart, Sparkles, Award, Megaphone,
  Library, Briefcase, MapPin, Shield, Bell, Zap, Calendar,
};
const ICON_OPTIONS = Object.keys(ICON_MAP);

const PRESET_COLORS = [
  '#6366f1', '#8b5cf6', '#ec4899', '#ef4444', '#f97316',
  '#f59e0b', '#10b981', '#14b8a6', '#06b6d4', '#3b82f6',
];

interface HubButton {
  id: string;
  name: string;
  url: string;
  description: string | null;
  icon: string;
  color: string;
  sort_order: number;
  is_active: boolean;
  schedule_start: string | null;
  schedule_end: string | null;
  open_in_new_tab: boolean;
}

interface HubSettings {
  id?: string;
  title: string;
  subtitle: string | null;
  description: string | null;
  accent_color: string;
}

const useClock = () => {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return now;
};

const FancyClock = ({ accent }: { accent: string }) => {
  const now = useClock();
  const time = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
  const [hh, mm, ss] = time.split(':');
  const date = now.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  return (
    <div
      className="relative overflow-hidden rounded-3xl p-6 md:p-8 text-white shadow-2xl"
      style={{ background: `linear-gradient(135deg, ${accent} 0%, #0f172a 100%)` }}
    >
      <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-white/10 blur-3xl animate-pulse" />
      <div className="absolute -bottom-16 -left-10 w-56 h-56 rounded-full bg-white/5 blur-3xl" />
      <div className="relative flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-white/15 backdrop-blur flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-white/70 uppercase tracking-widest">Waktu Sekarang</p>
            <p className="text-lg font-medium">{date}</p>
          </div>
        </div>
        <div className="flex items-end gap-2 font-mono">
          <span className="text-5xl md:text-7xl font-bold tabular-nums drop-shadow-lg">{hh}</span>
          <span className="text-4xl md:text-6xl opacity-60 animate-pulse">:</span>
          <span className="text-5xl md:text-7xl font-bold tabular-nums drop-shadow-lg">{mm}</span>
          <span className="text-2xl md:text-3xl opacity-70 mb-2 tabular-nums">{ss}</span>
        </div>
      </div>
    </div>
  );
};

const emptyButton: Omit<HubButton, 'id'> = {
  name: '', url: '', description: '', icon: 'Link', color: '#6366f1',
  sort_order: 0, is_active: true, schedule_start: null, schedule_end: null,
  open_in_new_tab: true,
};

type ButtonStatus = 'inactive' | 'upcoming' | 'active' | 'expired';

const getButtonStatus = (b: HubButton, now: number): ButtonStatus => {
  if (!b.is_active) return 'inactive';
  const start = b.schedule_start ? new Date(b.schedule_start).getTime() : null;
  const end = b.schedule_end ? new Date(b.schedule_end).getTime() : null;
  if (start && now < start) return 'upcoming';
  if (end && now > end) return 'expired';
  return 'active';
};

const fmtDuration = (ms: number) => {
  if (ms <= 0) return '0 detik';
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (d > 0) return `${d}h ${h}j ${m}m ${sec}d`;
  if (h > 0) return `${h}j ${m}m ${sec}d`;
  if (m > 0) return `${m}m ${sec}d`;
  return `${sec} detik`;
};

const fmtDateTime = (iso: string | null) => {
  if (!iso) return '-';
  return new Date(iso).toLocaleString('id-ID', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
};

const fmtTimeOnly = (iso: string | null) => {
  if (!iso) return '-';
  return new Date(iso).toLocaleTimeString('id-ID', {
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  });
};

/* ============ Live Button Card with internal 1s timer ============ */
interface HubButtonCardProps {
  button: HubButton;
  isAdmin: boolean;
  onEdit: (b: HubButton) => void;
  onDelete: (id: string) => void;
}

const HubButtonCard = memo(({ button: b, isAdmin, onEdit, onDelete }: HubButtonCardProps) => {
  const [nowMs, setNowMs] = useState(Date.now());

  useEffect(() => {
    const t = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  const Icon = ICON_MAP[b.icon] || LinkIcon;
  const status = getButtonStatus(b, nowMs);
  const start = b.schedule_start ? new Date(b.schedule_start).getTime() : null;
  const end = b.schedule_end ? new Date(b.schedule_end).getTime() : null;

  let progressLabel: string | null = null;
  let progressValue: number | null = null;
  let progressTone: 'open' | 'close' | 'wait' = 'open';

  if (status === 'upcoming' && start) {
    const remaining = start - nowMs;
    const windowMs = Math.min(7 * 86400 * 1000, Math.max(remaining, 60_000));
    progressValue = Math.max(0, Math.min(100, ((windowMs - remaining) / windowMs) * 100));
    progressLabel = `Dibuka dalam ${fmtDuration(remaining)}`;
    progressTone = 'wait';
  } else if (status === 'active' && end) {
    const total = start ?? (end - 86400 * 1000);
    const span = end - total;
    const elapsed = nowMs - total;
    progressValue = Math.max(0, Math.min(100, (elapsed / span) * 100));
    progressLabel = `Ditutup dalam ${fmtDuration(end - nowMs)}`;
    progressTone = 'close';
  } else if (status === 'active' && !end) {
    progressLabel = 'Aktif tanpa batas waktu';
  }

  const isGray = status === 'upcoming' || status === 'inactive' || status === 'expired';

  const handleClick = () => {
    if (status !== 'active') {
      if (status === 'upcoming') toast.info('Tombol belum aktif. Tunggu hingga waktu pembukaan.');
      else if (status === 'expired') toast.info('Tombol sudah berakhir.');
      else toast.info('Tombol dinonaktifkan.');
      return;
    }
    if (!b.url) return;
    const url = /^https?:\/\//i.test(b.url) ? b.url : `https://${b.url}`;
    if (b.open_in_new_tab) window.open(url, '_blank', 'noopener,noreferrer');
    else window.location.href = url;
  };

  return (
    <Card
      className={`group relative overflow-hidden rounded-2xl border-0 shadow-md transition-all duration-300 ${
        status === 'active' ? 'hover:shadow-2xl hover:-translate-y-1 cursor-pointer' : 'cursor-not-allowed'
      }`}
      onClick={handleClick}
    >
      {isGray ? (
        <div className="absolute inset-0 bg-gradient-to-br from-slate-400 via-slate-500 to-slate-700" />
      ) : (
        <>
          <div
            className="absolute inset-0 opacity-95"
            style={{ background: `linear-gradient(135deg, ${b.color} 0%, ${b.color}dd 50%, #0f172a 140%)` }}
          />
          <div className="absolute -top-10 -right-10 w-32 h-32 rounded-full bg-white/15 blur-2xl group-hover:scale-150 transition-transform duration-500" />
        </>
      )}

      <div className="relative p-5 text-white min-h-[220px] flex flex-col justify-between gap-3">
        <div className="flex items-start justify-between gap-2">
          <div className={`w-12 h-12 rounded-xl backdrop-blur flex items-center justify-center shadow-lg ${isGray ? 'bg-white/15' : 'bg-white/20'}`}>
            {status === 'upcoming' ? <Hourglass className="w-6 h-6" /> :
              status === 'inactive' ? <Lock className="w-6 h-6" /> :
              status === 'expired' ? <XCircle className="w-6 h-6" /> :
              <Icon className="w-6 h-6" />}
          </div>
          <div className="flex items-center gap-1">
            {status === 'active' && (
              <span className="inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider bg-emerald-500/90 px-2 py-1 rounded-full">
                <CheckCircle2 className="w-3 h-3" /> Aktif
              </span>
            )}
            {status === 'upcoming' && (
              <span className="inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider bg-amber-500/90 px-2 py-1 rounded-full">
                <Hourglass className="w-3 h-3" /> Belum Aktif
              </span>
            )}
            {status === 'expired' && (
              <span className="inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider bg-rose-500/90 px-2 py-1 rounded-full">
                <XCircle className="w-3 h-3" /> Berakhir
              </span>
            )}
            {status === 'inactive' && (
              <span className="inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider bg-slate-700/90 px-2 py-1 rounded-full">
                <Lock className="w-3 h-3" /> Nonaktif
              </span>
            )}
            {status === 'active' && (
              <ArrowUpRight className="w-5 h-5 opacity-80 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform ml-1" />
            )}
          </div>
        </div>

        <div className="flex-1">
          <h3 className="text-lg font-bold leading-tight">{b.name}</h3>
          {b.description && <p className="text-sm text-white/85 mt-1 line-clamp-2">{b.description}</p>}
        </div>

        {(b.schedule_start || b.schedule_end) && (
          <div className="space-y-1.5 pt-1 border-t border-white/15">
            <div className="flex items-center justify-between text-[11px] text-white/85">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" /> {fmtDateTime(b.schedule_start)}
              </span>
              <span>{fmtDateTime(b.schedule_end)}</span>
            </div>

            {/* Active time indicator */}
            {status === 'active' && (
              <div className="flex items-center gap-1.5 text-[11px] text-emerald-200">
                <Zap className="w-3 h-3" />
                <span>Jam aktif: {fmtTimeOnly(b.schedule_start)} – {fmtTimeOnly(b.schedule_end)}</span>
              </div>
            )}
            {status === 'upcoming' && (
              <div className="flex items-center gap-1.5 text-[11px] text-amber-200">
                <Hourglass className="w-3 h-3" />
                <span>Aktif mulai: {fmtTimeOnly(b.schedule_start)}</span>
              </div>
            )}

            {progressValue !== null && (
              <div className="h-2 bg-white/20 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-[width] duration-700 ease-linear ${
                    progressTone === 'close' ? 'bg-emerald-300' : 'bg-amber-300'
                  }`}
                  style={{ width: `${progressValue}%` }}
                />
              </div>
            )}
            {progressLabel && (
              <p className={`text-[11px] font-medium ${status === 'upcoming' ? 'text-amber-200 animate-pulse' : 'text-white/90'}`}>
                {progressLabel}
              </p>
            )}
          </div>
        )}

        {isAdmin && (
          <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button size="icon" variant="ghost" className="h-7 w-7 bg-black/30 hover:bg-black/50 text-white"
              onClick={(e) => { e.stopPropagation(); onEdit(b); }}>
              <Pencil className="w-3.5 h-3.5" />
            </Button>
            <Button size="icon" variant="ghost" className="h-7 w-7 bg-black/30 hover:bg-red-500/80 text-white"
              onClick={(e) => { e.stopPropagation(); onDelete(b.id); }}>
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
});
HubButtonCard.displayName = 'HubButtonCard';

const NedelcisHub = () => {
  const { user, userRole } = useAuth();
  const isAdmin = userRole === 'admin' || userRole === 'super_admin';
  const now = useClock();
  const nowMs = now.getTime();

  const [settings, setSettings] = useState<HubSettings>({
    title: 'Nedelcis Hub', subtitle: 'Pusat Akses Cepat',
    description: 'Kumpulan tautan penting untuk memudahkan akses berbagai layanan sekolah.',
    accent_color: '#6366f1',
  });
  const [buttons, setButtons] = useState<HubButton[]>([]);
  const [loading, setLoading] = useState(true);

  const [editSettingsOpen, setEditSettingsOpen] = useState(false);
  const [editButtonOpen, setEditButtonOpen] = useState(false);
  const [editingButton, setEditingButton] = useState<HubButton | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [showHiddenForAdmin, setShowHiddenForAdmin] = useState(false);

  const load = async () => {
    setLoading(true);
    const [{ data: s }, { data: bs }] = await Promise.all([
      supabase.from('nedelcis_hub_settings' as any).select('*').limit(1).maybeSingle(),
      supabase.from('nedelcis_hub_buttons' as any).select('*').order('sort_order', { ascending: true }),
    ]);
    if (s) setSettings(s as any);
    if (bs) setButtons(bs as any);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const visibleButtons = useMemo(() => {
    return buttons.filter(b => {
      if (isAdmin && showHiddenForAdmin) return true;
      const st = getButtonStatus(b, nowMs);
      return st === 'active' || st === 'upcoming';
    });
  }, [buttons, isAdmin, showHiddenForAdmin, nowMs]);

  const saveSettings = async () => {
    const payload = {
      title: settings.title,
      subtitle: settings.subtitle,
      description: settings.description,
      accent_color: settings.accent_color,
    };
    let res;
    if (settings.id) {
      res = await supabase.from('nedelcis_hub_settings' as any).update(payload).eq('id', settings.id);
    } else {
      res = await supabase.from('nedelcis_hub_settings' as any).insert(payload).select().single();
      if (!res.error && res.data) setSettings(res.data as any);
    }
    if (res.error) toast.error('Gagal menyimpan: ' + res.error.message);
    else { toast.success('Pengaturan tersimpan'); setEditSettingsOpen(false); load(); }
  };

  const saveButton = async () => {
    if (!editingButton) return;
    if (!editingButton.name.trim() || !editingButton.url.trim()) {
      toast.error('Nama dan URL wajib diisi'); return;
    }
    const { id, ...rest } = editingButton;
    const payload = {
      ...rest,
      schedule_start: rest.schedule_start || null,
      schedule_end: rest.schedule_end || null,
    };
    const res = id
      ? await supabase.from('nedelcis_hub_buttons' as any).update(payload).eq('id', id)
      : await supabase.from('nedelcis_hub_buttons' as any).insert(payload);
    if (res.error) toast.error('Gagal menyimpan: ' + res.error.message);
    else { toast.success('Tombol tersimpan'); setEditButtonOpen(false); setEditingButton(null); load(); }
  };

  const deleteButton = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from('nedelcis_hub_buttons' as any).delete().eq('id', deleteId);
    if (error) toast.error('Gagal menghapus'); else { toast.success('Tombol dihapus'); load(); }
    setDeleteId(null);
  };

  const openNewButton = () => {
    setEditingButton({ id: '', ...emptyButton, sort_order: buttons.length } as HubButton);
    setEditButtonOpen(true);
  };

  const activeCount = buttons.filter(b => getButtonStatus(b, nowMs) === 'active').length;
  const upcomingCount = buttons.filter(b => getButtonStatus(b, nowMs) === 'upcoming').length;

  const content = (
    <div className="space-y-6 p-4 md:p-6 max-w-7xl mx-auto">
      {/* Hero */}
      <div
        className="relative overflow-hidden rounded-3xl p-6 md:p-10 text-white shadow-2xl"
        style={{
          background: `linear-gradient(135deg, ${settings.accent_color} 0%, #1e1b4b 60%, #0f172a 100%)`,
        }}
      >
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-10 right-10 w-72 h-72 rounded-full bg-white/20 blur-3xl animate-pulse" />
          <div className="absolute -bottom-20 -left-10 w-80 h-80 rounded-full bg-purple-400/30 blur-3xl" />
        </div>
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur text-xs font-medium mb-3">
              <Sparkles className="w-3.5 h-3.5" /> {settings.subtitle || 'Pusat Akses Cepat'}
            </div>
            <h1 className="text-3xl md:text-5xl font-bold tracking-tight">{settings.title}</h1>
            {settings.description && (
              <p className="mt-3 text-white/80 max-w-2xl leading-relaxed">{settings.description}</p>
            )}
            <div className="flex flex-wrap gap-2 mt-4">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-300/30 text-xs font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" /> {activeCount} Aktif
              </span>
              {upcomingCount > 0 && (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-300/30 text-xs font-medium">
                  <Hourglass className="w-3.5 h-3.5" /> {upcomingCount} Menunggu
                </span>
              )}
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {isAdmin && (
              <>
                <Button onClick={() => setEditSettingsOpen(true)} variant="secondary" className="bg-white/15 text-white hover:bg-white/25 border border-white/20 backdrop-blur">
                  <SettingsIcon className="w-4 h-4" /> Edit Halaman
                </Button>
                <Button onClick={openNewButton} className="bg-white text-slate-900 hover:bg-white/90">
                  <Plus className="w-4 h-4" /> Tombol Baru
                </Button>
              </>
            )}
            {!user && (
              <Button asChild variant="secondary" className="bg-white/15 text-white hover:bg-white/25 border border-white/20 backdrop-blur">
                <Link to="/auth"><LogIn className="w-4 h-4" /> Masuk</Link>
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Clock */}
      <FancyClock accent={settings.accent_color} />

      {/* Admin toggle */}
      {isAdmin && (
        <div className="flex items-center justify-end gap-2 text-sm">
          <Switch checked={showHiddenForAdmin} onCheckedChange={setShowHiddenForAdmin} id="show-hidden" />
          <Label htmlFor="show-hidden" className="cursor-pointer text-muted-foreground">
            Tampilkan tombol tidak aktif / kadaluarsa
          </Label>
        </div>
      )}

      {/* Buttons grid */}
      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-48 rounded-2xl bg-muted animate-pulse" />
          ))}
        </div>
      ) : visibleButtons.length === 0 ? (
        <Card className="p-12 text-center border-dashed">
          <LinkIcon className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
          <p className="text-lg font-semibold">Belum ada tombol</p>
          <p className="text-sm text-muted-foreground mt-1">
            {isAdmin ? 'Klik "Tombol Baru" untuk menambahkan akses cepat.' : 'Admin belum menambahkan tombol di Hub ini.'}
          </p>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {visibleButtons.map(b => (
            <HubButtonCard
              key={b.id}
              button={b}
              isAdmin={isAdmin}
              onEdit={(btn) => { setEditingButton(btn); setEditButtonOpen(true); }}
              onDelete={(id) => setDeleteId(id)}
            />
          ))}
        </div>
      )}

      {!user && (
        <p className="text-center text-xs text-muted-foreground pt-4">
          Halaman publik &middot; Pengelolaan tombol hanya untuk admin yang sudah masuk.
        </p>
      )}
    </div>
  );

  return (
    <>
      {user ? (
        <DashboardLayout>{content}</DashboardLayout>
      ) : (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50 dark:from-slate-950 dark:via-slate-900 dark:to-indigo-950">
          {content}
        </div>
      )}

      {/* Edit settings dialog */}
      <Dialog open={editSettingsOpen} onOpenChange={setEditSettingsOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Halaman Nedelcis Hub</DialogTitle>
            <DialogDescription>Atur judul, deskripsi, dan warna aksen halaman.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div><Label>Judul</Label><Input value={settings.title} onChange={e => setSettings(s => ({ ...s, title: e.target.value }))} /></div>
            <div><Label>Subjudul</Label><Input value={settings.subtitle || ''} onChange={e => setSettings(s => ({ ...s, subtitle: e.target.value }))} /></div>
            <div><Label>Deskripsi</Label><Textarea rows={3} value={settings.description || ''} onChange={e => setSettings(s => ({ ...s, description: e.target.value }))} /></div>
            <div>
              <Label>Warna Aksen</Label>
              <div className="flex items-center gap-2 mt-1">
                <input type="color" value={settings.accent_color} onChange={e => setSettings(s => ({ ...s, accent_color: e.target.value }))} className="h-10 w-14 rounded border cursor-pointer" />
                <div className="flex flex-wrap gap-1">
                  {PRESET_COLORS.map(c => (
                    <button key={c} type="button" onClick={() => setSettings(s => ({ ...s, accent_color: c }))}
                      className="w-7 h-7 rounded-full border-2 border-white shadow" style={{ background: c }} />
                  ))}
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditSettingsOpen(false)}>Batal</Button>
            <Button onClick={saveSettings}>Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit button dialog */}
      <Dialog open={editButtonOpen} onOpenChange={(o) => { setEditButtonOpen(o); if (!o) setEditingButton(null); }}>
        <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingButton?.id ? 'Edit Tombol' : 'Tombol Baru'}</DialogTitle>
            <DialogDescription>Atur nama, URL, ikon, warna, dan jadwal tampil.</DialogDescription>
          </DialogHeader>
          {editingButton && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div><Label>Nama Tombol *</Label>
                  <Input value={editingButton.name} onChange={e => setEditingButton({ ...editingButton, name: e.target.value })} />
                </div>
                <div><Label>URL *</Label>
                  <Input placeholder="https://..." value={editingButton.url} onChange={e => setEditingButton({ ...editingButton, url: e.target.value })} />
                </div>
              </div>
              <div><Label>Deskripsi</Label>
                <Textarea rows={2} value={editingButton.description || ''} onChange={e => setEditingButton({ ...editingButton, description: e.target.value })} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Ikon</Label>
                  <div className="grid grid-cols-6 gap-1 mt-1 max-h-32 overflow-y-auto p-2 border rounded-md">
                    {ICON_OPTIONS.map(name => {
                      const I = ICON_MAP[name];
                      const active = editingButton.icon === name;
                      return (
                        <button key={name} type="button" onClick={() => setEditingButton({ ...editingButton, icon: name })}
                          className={`p-2 rounded-md flex items-center justify-center hover:bg-accent ${active ? 'bg-primary text-primary-foreground' : ''}`}>
                          <I className="w-4 h-4" />
                        </button>
                      );
                    })}
                  </div>
                </div>
                <div>
                  <Label>Warna</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <input type="color" value={editingButton.color} onChange={e => setEditingButton({ ...editingButton, color: e.target.value })} className="h-10 w-14 rounded border cursor-pointer" />
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {PRESET_COLORS.map(c => (
                      <button key={c} type="button" onClick={() => setEditingButton({ ...editingButton, color: c })}
                        className="w-6 h-6 rounded-full border-2 border-white shadow" style={{ background: c }} />
                    ))}
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Urutan</Label>
                  <Input type="number" value={editingButton.sort_order} onChange={e => setEditingButton({ ...editingButton, sort_order: parseInt(e.target.value) || 0 })} />
                </div>
                <div className="flex items-end gap-4 pb-2">
                  <div className="flex items-center gap-2">
                    <Switch checked={editingButton.is_active} onCheckedChange={v => setEditingButton({ ...editingButton, is_active: v })} />
                    <Label>Aktif</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch checked={editingButton.open_in_new_tab} onCheckedChange={v => setEditingButton({ ...editingButton, open_in_new_tab: v })} />
                    <Label>Tab baru</Label>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="flex items-center gap-1"><Calendar className="w-3 h-3" />Mulai Tampil</Label>
                  <Input type="datetime-local"
                    value={editingButton.schedule_start ? editingButton.schedule_start.slice(0, 16) : ''}
                    onChange={e => setEditingButton({ ...editingButton, schedule_start: e.target.value ? new Date(e.target.value).toISOString() : null })} />
                </div>
                <div><Label className="flex items-center gap-1"><Calendar className="w-3 h-3" />Berakhir</Label>
                  <Input type="datetime-local"
                    value={editingButton.schedule_end ? editingButton.schedule_end.slice(0, 16) : ''}
                    onChange={e => setEditingButton({ ...editingButton, schedule_end: e.target.value ? new Date(e.target.value).toISOString() : null })} />
                </div>
              </div>
              <p className="text-xs text-muted-foreground">Kosongkan tanggal jadwal jika ingin tombol selalu tampil saat aktif.</p>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => { setEditButtonOpen(false); setEditingButton(null); }}>Batal</Button>
            <Button onClick={saveButton}>Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus tombol?</AlertDialogTitle>
            <AlertDialogDescription>Tombol akan dihapus permanen dari Nedelcis Hub.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={deleteButton} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Hapus</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default NedelcisHub;
