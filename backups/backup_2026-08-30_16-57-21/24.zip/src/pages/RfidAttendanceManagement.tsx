import { useEffect, useMemo, useState } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import {
  CreditCard, Clock, Save, Search, ScanLine, Loader2, FileSpreadsheet, FileText,
  ChevronLeft, ChevronRight, ShieldCheck,
} from "lucide-react";

const STATUSES = ["hadir", "terlambat", "izin", "sakit", "alpa"] as const;

const todayStr = () => {
  const d = new Date(Date.now() + 7 * 3600_000);
  return d.toISOString().slice(0, 10);
};
const timeOf = (iso: string | null) =>
  iso ? new Date(iso).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: "Asia/Jakarta" }) : "";

const toIso = (date: string, hhmm: string) =>
  hhmm ? new Date(`${date}T${hhmm}:00+07:00`).toISOString() : null;

const statusColor: Record<string, string> = {
  hadir: "bg-emerald-500 text-white",
  terlambat: "bg-amber-500 text-white",
  izin: "bg-sky-500 text-white",
  sakit: "bg-violet-500 text-white",
  alpa: "bg-destructive text-destructive-foreground",
};

const RfidAttendanceManagementPage = () => {
  const { toast } = useToast();
  const { userRole } = useAuth();
  const qc = useQueryClient();
  const isAdmin = userRole === "admin" || userRole === "super_admin";

  const [date, setDate] = useState(todayStr());
  const [classFilter, setClassFilter] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [savingId, setSavingId] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  const { data: classes } = useQuery({
    queryKey: ["rfid-classes"],
    queryFn: async () => {
      const { data, error } = await supabase.from("classes").select("id, name").order("name");
      if (error) throw error;
      return data;
    },
  });

  const { data: students, isLoading: studentsLoading } = useQuery({
    queryKey: ["rfid-students"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("students")
        .select("id, full_name, nis, rfid_uid, class_id, status, is_alumni, classes(name)")
        .eq("status", "aktif")
        .or("is_alumni.is.null,is_alumni.eq.false")
        .order("full_name");
      if (error) throw error;
      return data as any[];
    },
  });

  const { data: records } = useQuery({
    queryKey: ["rfid-records", date],
    queryFn: async () => {
      const { data, error } = await supabase.from("rfid_attendance").select("*").eq("date", date);
      if (error) throw error;
      return data as any[];
    },
  });

  const { data: settings } = useQuery({
    queryKey: ["rfid-settings"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("rfid_attendance_settings").select("*").order("created_at").limit(1).maybeSingle();
      if (error) throw error;
      return data as any;
    },
  });

  const [form, setForm] = useState<any>(null);
  const settingsForm = form ?? settings;

  const rows = useMemo(() => {
    const byStudent = new Map((records ?? []).map((r) => [r.student_id, r]));
    return (students ?? [])
      .filter((s) => classFilter === "all" || s.class_id === classFilter)
      .filter((s) =>
        !search ||
        s.full_name.toLowerCase().includes(search.toLowerCase()) ||
        (s.nis ?? "").includes(search))
      .map((s) => ({ student: s, record: byStudent.get(s.id) }))
      .filter(({ record }) =>
        statusFilter === "all" ||
        (statusFilter === "belum" ? !record?.status : record?.status === statusFilter));
  }, [students, records, classFilter, search, statusFilter]);

  const totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
  const pagedRows = useMemo(
    () => rows.slice((page - 1) * pageSize, page * pageSize),
    [rows, page, pageSize]
  );

  useEffect(() => { setPage(1); }, [date, classFilter, search, statusFilter, pageSize]);

  const exportRows = () =>
    rows.map(({ student, record }, i) => ({
      No: i + 1,
      Nama: student.full_name,
      NIS: student.nis ?? "-",
      Kelas: student.classes?.name ?? "-",
      Masuk: timeOf(record?.check_in_at) || "-",
      Pulang: timeOf(record?.check_out_at) || "-",
      Status: record?.status ?? "Belum absen",
      Catatan: record?.notes ?? "",
    }));

  const exportExcel = () => {
    const ws = XLSX.utils.json_to_sheet(exportRows());
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Absensi RFID");
    XLSX.writeFile(wb, `absensi-rfid-${date}.xlsx`);
    toast({ title: "Excel diunduh", description: `${rows.length} baris diekspor.` });
  };

  const exportPdf = () => {
    const doc = new jsPDF({ orientation: "landscape" });
    doc.setFontSize(14);
    doc.text("Rekap Absensi RFID", 14, 15);
    doc.setFontSize(10);
    doc.text(`Tanggal: ${date}  •  Total: ${rows.length} siswa`, 14, 22);
    autoTable(doc, {
      startY: 27,
      head: [["No", "Nama", "NIS", "Kelas", "Masuk", "Pulang", "Status", "Catatan"]],
      body: exportRows().map((r) => Object.values(r).map(String)),
      styles: { fontSize: 8 },
      headStyles: { fillColor: [37, 99, 235] },
    });
    doc.save(`absensi-rfid-${date}.pdf`);
    toast({ title: "PDF diunduh", description: `${rows.length} baris diekspor.` });
  };


  const saveRecord = async (studentId: string, patch: { check_in?: string; check_out?: string; status?: string; notes?: string }, existing: any) => {
    setSavingId(studentId);
    try {
      const payload: any = {};
      if (patch.check_in !== undefined) payload.check_in_at = toIso(date, patch.check_in);
      if (patch.check_out !== undefined) payload.check_out_at = toIso(date, patch.check_out);
      if (patch.status !== undefined) payload.status = patch.status;
      if (patch.notes !== undefined) payload.notes = patch.notes;

      if (existing) {
        const { error } = await supabase.from("rfid_attendance").update(payload).eq("id", existing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("rfid_attendance")
          .insert({ student_id: studentId, date, status: payload.status ?? "hadir", ...payload });
        if (error) throw error;
      }
      await qc.invalidateQueries({ queryKey: ["rfid-records", date] });
      toast({ title: "Tersimpan", description: "Data absensi diperbarui." });
    } catch (e: any) {
      toast({ title: "Gagal menyimpan", description: e.message, variant: "destructive" });
    } finally {
      setSavingId(null);
    }
  };

  const saveUid = async (studentId: string, uid: string) => {
    setSavingId(studentId);
    try {
      const { error } = await supabase
        .from("students")
        .update({ rfid_uid: uid.trim() || null })
        .eq("id", studentId);
      if (error) throw error;
      await qc.invalidateQueries({ queryKey: ["rfid-students"] });
      toast({ title: "Kartu tersimpan", description: uid ? `UID: ${uid}` : "Kartu dilepas dari siswa." });
    } catch (e: any) {
      toast({
        title: "Gagal menyimpan kartu",
        description: e.message?.includes("duplicate") ? "UID kartu sudah dipakai siswa lain." : e.message,
        variant: "destructive",
      });
    } finally {
      setSavingId(null);
    }
  };

  const saveSettings = async () => {
    if (!settingsForm) return;
    try {
      const payload = {
        check_in_start: settingsForm.check_in_start,
        check_in_end: settingsForm.check_in_end,
        late_after: settingsForm.late_after,
        check_out_start: settingsForm.check_out_start,
        check_out_end: settingsForm.check_out_end,
        is_active: settingsForm.is_active,
        late_violation_enabled: settingsForm.late_violation_enabled ?? false,
        late_violation_points: Number(settingsForm.late_violation_points ?? 5),
        face_verification_enabled: settingsForm.face_verification_enabled ?? false,
      };
      const { error } = settings?.id
        ? await supabase.from("rfid_attendance_settings").update(payload).eq("id", settings.id)
        : await supabase.from("rfid_attendance_settings").insert(payload);
      if (error) throw error;
      await qc.invalidateQueries({ queryKey: ["rfid-settings"] });
      toast({ title: "Pengaturan disimpan" });
    } catch (e: any) {
      toast({ title: "Gagal menyimpan", description: e.message, variant: "destructive" });
    }
  };

  const registered = (students ?? []).filter((s) => s.rfid_uid).length;

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <ScanLine className="h-6 w-6 text-primary" /> Absensi RFID
          </h1>
          <p className="text-sm text-muted-foreground">
            Kelola kehadiran kartu RFID, registrasi kartu siswa, dan jadwal absensi.
          </p>
        </div>

        <Tabs defaultValue="rekap">
          <TabsList>
            <TabsTrigger value="rekap">Rekap & Edit</TabsTrigger>
            {isAdmin && <TabsTrigger value="kartu">Registrasi Kartu</TabsTrigger>}
            {isAdmin && <TabsTrigger value="jadwal">Jadwal Absensi</TabsTrigger>}
          </TabsList>

          <TabsContent value="rekap" className="mt-4 space-y-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Filter</CardTitle>
              </CardHeader>
              <CardContent className="grid gap-3 md:grid-cols-3 lg:grid-cols-5">
                <div>
                  <Label>Tanggal</Label>
                  <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                </div>
                <div>
                  <Label>Kelas</Label>
                  <Select value={classFilter} onValueChange={setClassFilter}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Kelas</SelectItem>
                      {classes?.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Status</Label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Status</SelectItem>
                      <SelectItem value="belum">Belum absen</SelectItem>
                      {STATUSES.map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Baris / Halaman</Label>
                  <Select value={String(pageSize)} onValueChange={(v) => setPageSize(Number(v))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {[10, 25, 50, 100].map((n) => <SelectItem key={n} value={String(n)}>{n}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Cari Siswa</Label>
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input className="pl-8" placeholder="Nama atau NIS" value={search} onChange={(e) => setSearch(e.target.value)} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3 flex-row items-start justify-between gap-3 space-y-0">
                <div>
                  <CardTitle className="text-base">Daftar Kehadiran ({rows.length})</CardTitle>
                  <CardDescription>Wali kelas, guru piket, dan admin dapat mengubah data.</CardDescription>
                </div>
                <div className="flex gap-2 shrink-0">
                  <Button variant="outline" size="sm" onClick={exportExcel} className="gap-1">
                    <FileSpreadsheet className="h-4 w-4" /> Excel
                  </Button>
                  <Button variant="outline" size="sm" onClick={exportPdf} className="gap-1">
                    <FileText className="h-4 w-4" /> PDF
                  </Button>
                </div>
              </CardHeader>

              <CardContent className="overflow-x-auto">
                {studentsLoading ? (
                  <div className="py-10 text-center text-muted-foreground">Memuat data…</div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Siswa</TableHead>
                        <TableHead>Kelas</TableHead>
                        <TableHead>Masuk</TableHead>
                        <TableHead>Pulang</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Catatan</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {pagedRows.map(({ student, record }) => (
                        <TableRow key={student.id}>
                          <TableCell>
                            <p className="font-medium">{student.full_name}</p>
                            <p className="text-xs text-muted-foreground">{student.nis}</p>
                          </TableCell>
                          <TableCell className="text-sm">{student.classes?.name ?? "-"}</TableCell>
                          <TableCell>
                            <Input
                              type="time"
                              className="w-28"
                              defaultValue={timeOf(record?.check_in_at)}
                              onBlur={(e) => {
                                if (e.target.value !== timeOf(record?.check_in_at))
                                  saveRecord(student.id, { check_in: e.target.value }, record);
                              }}
                            />
                          </TableCell>
                          <TableCell>
                            <Input
                              type="time"
                              className="w-28"
                              defaultValue={timeOf(record?.check_out_at)}
                              onBlur={(e) => {
                                if (e.target.value !== timeOf(record?.check_out_at))
                                  saveRecord(student.id, { check_out: e.target.value }, record);
                              }}
                            />
                          </TableCell>
                          <TableCell>
                            <Select
                              value={record?.status ?? ""}
                              onValueChange={(v) => saveRecord(student.id, { status: v }, record)}
                            >
                              <SelectTrigger className="w-32">
                                {record?.status
                                  ? <Badge className={statusColor[record.status] ?? ""}>{record.status}</Badge>
                                  : <span className="text-muted-foreground text-sm">Belum absen</span>}
                              </SelectTrigger>
                              <SelectContent>
                                {STATUSES.map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <Input
                                className="w-44"
                                placeholder="Catatan"
                                defaultValue={record?.notes ?? ""}
                                onBlur={(e) => {
                                  if (e.target.value !== (record?.notes ?? ""))
                                    saveRecord(student.id, { notes: e.target.value }, record);
                                }}
                              />
                              {savingId === student.id && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                      {pagedRows.length === 0 && (
                        <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground">Tidak ada data siswa.</TableCell></TableRow>
                      )}
                    </TableBody>
                  </Table>
                )}

                <div className="flex flex-wrap items-center justify-between gap-3 pt-4">
                  <p className="text-xs text-muted-foreground">
                    Menampilkan {pagedRows.length} dari {rows.length} siswa • Halaman {page}/{totalPages}
                  </p>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                      <ChevronLeft className="h-4 w-4" /> Sebelumnya
                    </Button>
                    <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
                      Berikutnya <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>

            </Card>
          </TabsContent>

          {isAdmin && (
            <TabsContent value="kartu" className="mt-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <CreditCard className="h-4 w-4 text-primary" /> Registrasi Kartu RFID
                  </CardTitle>
                  <CardDescription>
                    {registered} dari {students?.length ?? 0} siswa sudah memiliki kartu. Klik kolom UID lalu tap kartu pada pembaca.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="relative max-w-sm">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input className="pl-8" placeholder="Cari nama atau NIS" value={search} onChange={(e) => setSearch(e.target.value)} />
                  </div>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Siswa</TableHead>
                          <TableHead>Kelas</TableHead>
                          <TableHead>UID Kartu</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {rows.map(({ student }) => (
                          <TableRow key={student.id}>
                            <TableCell>
                              <p className="font-medium">{student.full_name}</p>
                              <p className="text-xs text-muted-foreground">{student.nis}</p>
                            </TableCell>
                            <TableCell className="text-sm">{student.classes?.name ?? "-"}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                <Input
                                  className="w-56 font-mono"
                                  placeholder="Tap kartu di sini…"
                                  defaultValue={student.rfid_uid ?? ""}
                                  onKeyDown={(e) => { if (e.key === "Enter") (e.target as HTMLInputElement).blur(); }}
                                  onBlur={(e) => {
                                    if (e.target.value.trim() !== (student.rfid_uid ?? ""))
                                      saveUid(student.id, e.target.value);
                                  }}
                                />
                                {savingId === student.id && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
                              </div>
                            </TableCell>
                            <TableCell>
                              {student.rfid_uid
                                ? <Badge className="bg-emerald-500 text-white">Terdaftar</Badge>
                                : <Badge variant="outline">Belum ada kartu</Badge>}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {isAdmin && (
            <TabsContent value="jadwal" className="mt-4">
              <Card className="max-w-2xl">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Clock className="h-4 w-4 text-primary" /> Jadwal Absensi RFID
                  </CardTitle>
                  <CardDescription>Atur rentang waktu tap masuk, batas terlambat, dan tap pulang.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {settingsForm && (
                    <>
                      <div className="flex items-center justify-between rounded-lg border p-3">
                        <div>
                          <p className="font-medium text-sm">Aktifkan Absensi RFID</p>
                          <p className="text-xs text-muted-foreground">Nonaktifkan untuk menutup layar tap sementara.</p>
                        </div>
                        <Switch
                          checked={!!settingsForm.is_active}
                          onCheckedChange={(v) => setForm({ ...settingsForm, is_active: v })}
                        />
                      </div>
                      <div className="grid gap-3 sm:grid-cols-2">
                        {[
                          ["check_in_start", "Mulai Tap Masuk"],
                          ["check_in_end", "Akhir Tap Masuk"],
                          ["late_after", "Terlambat Setelah"],
                          ["check_out_start", "Mulai Tap Pulang"],
                          ["check_out_end", "Akhir Tap Pulang"],
                        ].map(([key, label]) => (
                          <div key={key}>
                            <Label>{label}</Label>
                            <Input
                              type="time"
                              value={String(settingsForm[key] ?? "").slice(0, 5)}
                              onChange={(e) => setForm({ ...settingsForm, [key]: e.target.value })}
                            />
                          </div>
                        ))}
                      </div>

                      <div className="flex items-center justify-between rounded-lg border p-3">
                        <div>
                          <p className="font-medium text-sm">Poin Pelanggaran Otomatis (Terlambat)</p>
                          <p className="text-xs text-muted-foreground">Siswa yang tap terlambat otomatis tercatat sebagai pelanggaran.</p>
                        </div>
                        <Switch
                          checked={!!settingsForm.late_violation_enabled}
                          onCheckedChange={(v) => setForm({ ...settingsForm, late_violation_enabled: v })}
                        />
                      </div>
                      {settingsForm.late_violation_enabled && (
                        <div className="max-w-[200px]">
                          <Label>Jumlah Poin</Label>
                          <Input
                            type="number"
                            min={1}
                            value={settingsForm.late_violation_points ?? 5}
                            onChange={(e) => setForm({ ...settingsForm, late_violation_points: e.target.value })}
                          />
                        </div>
                      )}

                      <div className="flex items-center justify-between rounded-lg border p-3">
                        <div>
                          <p className="font-medium text-sm flex items-center gap-2">
                            <ShieldCheck className="h-4 w-4 text-primary" /> Verifikasi Wajah
                          </p>
                          <p className="text-xs text-muted-foreground">Wajibkan verifikasi kamera setelah tap kartu.</p>
                        </div>
                        <Switch
                          checked={!!settingsForm.face_verification_enabled}
                          onCheckedChange={(v) => setForm({ ...settingsForm, face_verification_enabled: v })}
                        />
                      </div>

                      <Button onClick={saveSettings} className="gap-2">
                        <Save className="h-4 w-4" /> Simpan Pengaturan
                      </Button>
                    </>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          )}
        </Tabs>
      </div>
    </DashboardLayout>
  );
};

const RfidAttendanceManagement = () => (
  <ProtectedRoute allowedRoles={["admin", "super_admin", "guru_piket", "kesiswaan", "teacher"]}>
    <RfidAttendanceManagementPage />
  </ProtectedRoute>
);

export default RfidAttendanceManagement;
