import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

const FIELDS: { key: string; label: string; type?: string }[] = [
  { key: "site_name", label: "Nama Website" },
  { key: "tagline", label: "Tagline" },
  { key: "about_short", label: "Tentang Singkat", type: "textarea" },
  { key: "address", label: "Alamat", type: "textarea" },
  { key: "phone", label: "Telepon" },
  { key: "email", label: "Email" },
  { key: "whatsapp", label: "WhatsApp (contoh: 6281xxx)" },
  { key: "logo_url", label: "URL Logo" },
  { key: "facebook_url", label: "Facebook URL" },
  { key: "instagram_url", label: "Instagram URL" },
  { key: "youtube_url", label: "YouTube URL" },
  { key: "tiktok_url", label: "TikTok URL" },
  { key: "map_embed_url", label: "Google Maps (tempel URL src ATAU seluruh kode <iframe>)", type: "textarea" },
  { key: "meta_title", label: "SEO Title" },
  { key: "meta_description", label: "SEO Description", type: "textarea" },
  { key: "meta_keywords", label: "SEO Keywords" },
  { key: "instagram_section_title", label: "Judul Section Instagram" },
  { key: "instagram_username", label: "Instagram Username (tanpa @)" },
  { key: "instagram_post_urls", label: "URL Post Instagram (satu URL per baris, mis. https://www.instagram.com/p/XXXX/)", type: "textarea" },
];

export default function AdminSettings() {
  const [row, setRow] = useState<any>(null);
  const [form, setForm] = useState<any>({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    (supabase.from("website_settings" as any) as any).select("*").order("created_at", { ascending: false }).limit(1).maybeSingle().then(({ data }: any) => {
      setRow(data); setForm(data ?? {});
    });
  }, []);

  const save = async () => {
    setLoading(true);
    const q: any = supabase.from("website_settings" as any);
    const { error } = row
      ? await q.update(form).eq("id", row.id)
      : await q.insert(form);
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Pengaturan disimpan");
  };

  return (
    <div className="p-8 max-w-3xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Pengaturan Website</h1>
        <p className="text-sm text-slate-500">Identitas, kontak, sosial media, dan SEO.</p>
      </div>
      <div className="bg-white rounded-2xl border p-6 grid md:grid-cols-2 gap-4">
        {FIELDS.map((f) => (
          <div key={f.key} className={f.type === "textarea" ? "md:col-span-2" : ""}>
            <Label className="mb-1 block">{f.label}</Label>
            {f.type === "textarea"
              ? <Textarea rows={3} value={form[f.key] ?? ""} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} />
              : <Input value={form[f.key] ?? ""} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} />}
          </div>
        ))}
      </div>
      <div className="mt-6 flex justify-end">
        <Button disabled={loading} onClick={save} className="bg-[#1E40AF] hover:bg-[#1E3A8A]">{loading ? "Menyimpan…" : "Simpan Perubahan"}</Button>
      </div>
    </div>
  );
}
