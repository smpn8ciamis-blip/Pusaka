import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, Calendar, User } from "lucide-react";

export default function BeritaDetail() {
  const { slug } = useParams();
  const [n, setN] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (supabase.from("website_news" as any) as any)
      .select("*, website_news_categories(name,color)")
      .eq("slug", slug!).eq("status", "published").maybeSingle()
      .then(({ data }: any) => { setN(data); setLoading(false); });
  }, [slug]);

  if (loading) return <div className="py-32 text-center text-slate-500">Memuat…</div>;
  if (!n) return <div className="py-32 text-center text-slate-500">Berita tidak ditemukan.<div className="mt-4"><Link to="/website/berita" className="text-[#1E40AF]">← Kembali ke daftar berita</Link></div></div>;

  return (
    <article className="max-w-3xl mx-auto px-4 py-16">
      <Link to="/website/berita" className="inline-flex items-center gap-2 text-sm text-[#1E40AF] hover:underline mb-6"><ArrowLeft className="h-4 w-4" /> Kembali ke daftar</Link>
      {n.website_news_categories && <span className="inline-block text-xs font-semibold px-2 py-1 rounded mb-3" style={{ background: `${n.website_news_categories.color}20`, color: n.website_news_categories.color }}>{n.website_news_categories.name}</span>}
      <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">{n.title}</h1>
      <div className="flex items-center gap-4 text-sm text-slate-500 mb-6">
        {n.published_at && <span className="flex items-center gap-1"><Calendar className="h-4 w-4" />{new Date(n.published_at).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })}</span>}
        {n.author_name && <span className="flex items-center gap-1"><User className="h-4 w-4" />{n.author_name}</span>}
      </div>
      {n.cover_image_url && <img src={n.cover_image_url} alt={n.title} className="w-full rounded-2xl mb-8" />}
      {n.excerpt && <p className="text-lg text-slate-700 font-medium mb-6">{n.excerpt}</p>}
      {/^\s*</.test(n.content ?? "") ? (
        <div className="prose prose-slate max-w-none leading-relaxed text-slate-700 prose-headings:text-slate-900 prose-a:text-[#1E40AF] prose-img:rounded-xl" dangerouslySetInnerHTML={{ __html: n.content ?? "" }} />
      ) : (
        <div className="prose prose-slate max-w-none whitespace-pre-line leading-relaxed text-slate-700">{n.content}</div>
      )}
    </article>
  );
}
