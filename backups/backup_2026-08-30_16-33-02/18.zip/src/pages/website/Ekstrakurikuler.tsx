import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHero } from "./Profil";
import { Activity } from "lucide-react";

export default function Ekstrakurikuler() {
  const [items, setItems] = useState<any[]>([]);
  useEffect(() => {
    (supabase.from("extracurricular_types" as any) as any)
      .select("*").eq("is_active", true).order("name")
      .then(({ data }: any) => setItems(data ?? []));
  }, []);
  return (
    <div>
      <PageHero title="Ekstrakurikuler" subtitle="Wadah pengembangan bakat, minat, dan karakter peserta didik." />
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((e) => (
            <div key={e.id} className="bg-white rounded-2xl p-6 border border-slate-100 hover:shadow-lg hover:border-[#1E40AF] transition">
              <div className="h-12 w-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4">
                <Activity className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold">{e.name}</h3>
              {e.description && <p className="text-slate-600 text-sm mt-2">{e.description}</p>}
            </div>
          ))}
        </div>
        {items.length === 0 && <div className="text-center text-slate-500 py-16">Data ekstrakurikuler belum tersedia.</div>}
      </div>
    </div>
  );
}
