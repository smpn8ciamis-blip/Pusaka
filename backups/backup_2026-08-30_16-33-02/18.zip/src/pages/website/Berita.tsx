import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { PageHero } from "./Profil";
import { Input } from "@/components/ui/input";
import { Search, Newspaper } from "lucide-react";

export default function Berita() {
  const [news, setNews] = useState<any[]>([]);
  const [cats, setCats] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      const [n, c] = await Promise.all([
        (supabase.from("website_news" as any) as any).select("*, website_news_categories(name,color)").eq("status", "published").order("published_at", { ascending: false }),
        (supabase.from("website_news_categories" as any) as any).select("*").order("name"),
      ]);
      setNews(n.data ?? []);
      setCats(c.data ?? []);
    })();
  }, []);

  const filtered = news.filter(
    (n) => (!cat || n.category_id === cat) && (!q || n.title.toLowerCase().includes(q.toLowerCase()))
  );

  return (
    <div>
      <PageHero title="Berita & Informasi" subtitle="Kabar terkini seputar kegiatan, prestasi, dan pengumuman sekolah." />
      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-wrap items-center gap-3 mb-8">
          <div className="relative flex-1 min-w-[240px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <Input placeholder="Cari berita…" value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
          </div>
          <button onClick={() => setCat(null)} className={`px-3 py-1.5 rounded-full text-sm ${!cat ? "bg-[#1E40AF] text-white" : "bg-slate-100 text-slate-700"}`}>Semua</button>
          {cats.map((c) => (
            <button key={c.id} onClick={() => setCat(c.id)} className={`px-3 py-1.5 rounded-full text-sm ${cat === c.id ? "text-white" : "text-slate-700 bg-slate-100"}`} style={cat === c.id ? { background: c.color } : {}}>
              {c.name}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-16 text-slate-500">
            <Newspaper className="h-12 w-12 mx-auto mb-3 opacity-40" /> Tidak ada berita.
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((n) => (
              <Link key={n.id} to={`/website/berita/${n.slug}`} className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl border border-slate-100 transition">
                <div className="aspect-video bg-slate-100">
                  {n.cover_image_url ? <img src={n.cover_image_url} alt={n.title} className="w-full h-full object-cover group-hover:scale-105 transition" /> : <div className="w-full h-full bg-gradient-to-br from-blue-100 to-blue-50 flex items-center justify-center text-blue-300"><Newspaper className="h-12 w-12" /></div>}
                </div>
                <div className="p-5">
                  {n.website_news_categories && <span className="inline-block text-xs font-semibold px-2 py-1 rounded" style={{ background: `${n.website_news_categories.color}20`, color: n.website_news_categories.color }}>{n.website_news_categories.name}</span>}
                  <h3 className="mt-3 font-bold text-slate-900 line-clamp-2 group-hover:text-[#1E40AF]">{n.title}</h3>
                  <p className="mt-2 text-sm text-slate-600 line-clamp-2">{n.excerpt}</p>
                  <div className="mt-3 text-xs text-slate-400">{n.published_at ? new Date(n.published_at).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" }) : ""}</div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
