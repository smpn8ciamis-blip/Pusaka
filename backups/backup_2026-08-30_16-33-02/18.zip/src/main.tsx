import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AcademicYearProvider } from "./contexts/AcademicYearContext";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ThemeProvider>
      <AcademicYearProvider>
        <App />
      </AcademicYearProvider>
    </ThemeProvider>
  </StrictMode>
);
