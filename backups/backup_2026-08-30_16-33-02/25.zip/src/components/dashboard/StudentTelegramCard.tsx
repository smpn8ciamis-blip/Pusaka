import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Send, Link2, Save, Trash2, Loader2 } from "lucide-react";

export const StudentTelegramCard = ({ studentId }: { studentId?: string }) => {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [manual, setManual] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const { data: bot } = useQuery({
    queryKey: ["telegram-bot-info"],
    queryFn: async () => {
      const { data, error } = await (supabase as any).rpc("get_telegram_bot_info");
      if (error) throw error;
      return data as { enabled: boolean; bot_username: string | null } | null;
    },
  });

  const { data: chatId, isLoading } = useQuery({
    queryKey: ["my-telegram-chat-id", studentId],
    queryFn: async () => {
      const { data, error } = await (supabase as any).rpc("get_my_telegram_chat_id");
      if (error) throw error;
      return (data as string | null) ?? "";
    },
  });

  const value = manual ?? chatId ?? "";

  const save = async (next: string) => {
    setSaving(true);
    try {
      const { data, error } = await (supabase as any).rpc("set_my_telegram_chat_id", { _chat_id: next });
      if (error) throw error;
      if (data === false) throw new Error("Akun Anda belum terhubung ke data siswa.");
      setManual(null);
      await qc.invalidateQueries({ queryKey: ["my-telegram-chat-id"] });
      toast({ title: next ? "ID chat Telegram tersimpan" : "ID chat Telegram dihapus" });
    } catch (e: any) {
      toast({ title: "Gagal menyimpan", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const connectUrl =
    bot?.bot_username && studentId ? `https://t.me/${bot.bot_username}?start=${studentId}` : null;

  return (
    <Card className="shadow-sm border-border/50">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <div className="w-8 h-8 bg-sky-500/10 rounded-lg flex items-center justify-center">
            <Send className="h-4 w-4 text-sky-500" />
          </div>
          Notifikasi Telegram Orang Tua
        </CardTitle>
        <CardDescription>
          Hubungkan Telegram agar orang tua menerima notifikasi setiap kali Anda tap kartu absensi.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Status:</span>
          {isLoading ? (
            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
          ) : chatId ? (
            <Badge className="bg-emerald-500 text-white">Terhubung</Badge>
          ) : (
            <Badge variant="outline">Belum terhubung</Badge>
          )}
        </div>

        {connectUrl ? (
          <Button asChild className="gap-2 w-full sm:w-auto">
            <a href={connectUrl} target="_blank" rel="noreferrer">
              <Link2 className="h-4 w-4" /> Deteksi Otomatis via Telegram
            </a>
          </Button>
        ) : (
          <p className="text-xs text-muted-foreground">
            Bot Telegram belum dikonfigurasi admin. Anda masih bisa mengisi ID chat manual di bawah.
          </p>
        )}

        <div className="space-y-2">
          <Label>ID Chat Telegram (manual)</Label>
          <div className="flex flex-col sm:flex-row gap-2">
            <Input
              className="font-mono"
              placeholder="mis. 123456789"
              value={value}
              onChange={(e) => setManual(e.target.value)}
            />
            <div className="flex gap-2">
              <Button onClick={() => save(value)} disabled={saving} className="gap-2">
                <Save className="h-4 w-4" /> Simpan
              </Button>
              <Button
                variant="outline"
                disabled={saving || !chatId}
                onClick={() => save("")}
                className="gap-2"
              >
                <Trash2 className="h-4 w-4" /> Hapus
              </Button>
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            Untuk mengetahui ID chat, kirim pesan apa pun ke bot sekolah — bot akan membalas dengan ID chat Anda.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};
