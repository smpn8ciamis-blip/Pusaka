import { useAuth } from '@/contexts/AuthContext';
import { SubscriptionBanner } from '@/components/SubscriptionBanner';
import { Button } from '@/components/ui/button';
import { LogOut, GraduationCap, Users, Calendar, BookOpen, FileText, ClipboardList, UserCircle, Settings, Menu, X, TrendingUp, Shield, UserCheck, Megaphone, FileCheck, CalendarClock, Mail, ChevronLeft, ChevronRight, ChevronDown, ChevronUp, AlertTriangle, BarChart3, FolderOpen, MessageSquare, Database, Award, FileSignature, Plane, Receipt, FileSpreadsheet, Wallet, FileBarChart, Inbox, Send, Hammer, Vote, Upload, Bell, Lock, Landmark, Server, UserMinus } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { AppFooter } from '@/components/AppFooter';
import { useQuery } from '@tanstack/react-query';
import { NotificationBell } from '@/components/NotificationBell';
import { AcademicYearSelector } from '@/components/AcademicYearSelector';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export const DashboardLayout = ({ children }: DashboardLayoutProps) => {
  const { user, userRole, signOut } = useAuth();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isHomeroomTeacher, setIsHomeroomTeacher] = useState(false);
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({
    'Master Data': false,
    'Akademik': false,
    'Laporan & Analytics': false,
    'Kesiswaan': false,
    'Informasi': false,
    'Keuangan': false,
    'Surat & Perjalanan': false,
    'Manajemen Akun': false,
    'Sistem': false,
    'Guru Piket': false,
    'Polling & Billing': false,
    'CBT': false,
  });

  // Fetch app name and logo from settings - using public view for teachers
  const { data: settings } = useQuery({
    queryKey: ['school-settings-navbar'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('school_settings_public')
        .select('app_name, right_logo_url')
        .limit(1)
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes
  });

  // Fetch user profile to get full name
  const { data: profile } = useQuery({
    queryKey: ['user-profile', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data, error } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', user.id)
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  const appName = settings?.app_name || 'Sistem Manajemen Sekolah';
  const rightLogoUrl = settings?.right_logo_url;

  // Update document title based on app name
  useEffect(() => {
    document.title = appName;
  }, [appName]);

  // Check if teacher is homeroom teacher by checking if they have a class assigned
  useEffect(() => {
    const checkHomeroomStatus = async () => {
      if (userRole === 'teacher' && user?.id) {
        // First get teacher ID
        const { data: teacher } = await supabase
          .from('teachers')
          .select('id')
          .eq('user_id', user.id)
          .maybeSingle();
        
        if (teacher) {
          // Then check if teacher has any classes as homeroom teacher
          const { data: classes } = await supabase
            .from('classes')
            .select('id')
            .eq('homeroom_teacher_id', teacher.id)
            .limit(1);
          
          setIsHomeroomTeacher((classes && classes.length > 0) || false);
        }
      }
    };
    
    checkHomeroomStatus();
  }, [user?.id, userRole]);

  type MenuItem = {
    icon: any;
    label: string;
    href: string;
    type?: 'item';
  };

  type MenuGroup = {
    label: string;
    items: MenuItem[];
  };

  const adminMenuGroups: MenuGroup[] = [
    {
      label: 'Master Data',
      items: [
        { icon: UserCircle, label: 'Guru', href: '/teachers' },
        { icon: Users, label: 'Siswa', href: '/students' },
        { icon: UserMinus, label: 'Mutasi Keluar', href: '/student-mutations' },
        { icon: BookOpen, label: 'Kelas', href: '/classes' },
        { icon: Award, label: 'Alumni', href: '/alumni' },
        { icon: CalendarClock, label: 'Tahun Pelajaran', href: '/academic-year-settings' },
      ]
    },
    {
      label: 'Akademik',
      items: [
        { icon: Calendar, label: 'Jadwal', href: '/schedules' },
        { icon: BarChart3, label: 'Beban Mengajar', href: '/teacher-workload' },
        { icon: ClipboardList, label: 'Absensi', href: '/attendance' },
        { icon: FileText, label: 'Jurnal Mengajar', href: '/journals' },
        { icon: GraduationCap, label: 'Nilai', href: '/grades' },
        { icon: FileCheck, label: 'Administrasi Ujian', href: '/exam-administration' },
      ]
    },
    {
      label: 'CBT',
      items: [
        { icon: FileCheck, label: 'Ujian CBT', href: '/cbt-management' },
      ]
    },
    {
      label: 'Laporan & Analytics',
      items: [
        { icon: TrendingUp, label: 'Analytics Kehadiran', href: '/analytics' },
        { icon: TrendingUp, label: 'Analytics Nilai', href: '/grade-analytics' },
        { icon: FileText, label: 'Rekap Absensi Siswa', href: '/student-attendance-report' },
      ]
    },
    {
      label: 'Kesiswaan',
      items: [
        { icon: Mail, label: 'Surat Izin Kegiatan', href: '/permission-letters' },
        { icon: AlertTriangle, label: 'Poin Pelanggaran', href: '/violations' },
        { icon: Award, label: 'Penghargaan & Prestasi', href: '/achievements' },
        { icon: FileText, label: 'Dispensasi Siswa', href: '/dispensasi-siswa' },
      ]
    },
    {
      label: 'Guru Piket',
      items: [
        { icon: Shield, label: 'Dashboard Guru Piket', href: '/guru-piket-dashboard' },
        { icon: BookOpen, label: 'Buku Tamu', href: '/buku-tamu' },
      ]
    },
    {
      label: 'Informasi',
      items: [
        { icon: Megaphone, label: 'Pengumuman', href: '/announcements' },
        { icon: FolderOpen, label: 'Repositori', href: '/repository' },
        { icon: FileText, label: 'Catatan Kejadian', href: '/important-event-notes' },
        { icon: MessageSquare, label: 'Pengaduan', href: '/manajemen-pengaduan' },
      ]
    },
    {
      label: 'Surat & Perjalanan',
      items: [
        { icon: FileSignature, label: 'Surat Tugas', href: '/assignment-letters' },
        { icon: Plane, label: 'SPPD', href: '/official-travel' },
        { icon: Inbox, label: 'Surat Masuk', href: '/surat-masuk' },
        { icon: Send, label: 'Surat Keluar', href: '/surat-keluar' },
      ]
    },
    {
      label: 'Keuangan',
      items: [
        { icon: Receipt, label: 'Kwitansi', href: '/payment-receipts' },
        { icon: Hammer, label: 'Upah Tukang', href: '/worker-payments' },
        { icon: GraduationCap, label: 'Honorarium GTT/PTT', href: '/gtt-ptt-honorarium' },
        { icon: Award, label: 'Honorarium Ekskul', href: '/extracurricular-honorarium' },
        { icon: Receipt, label: 'Kwitansi Narasumber', href: '/narasumber-honorarium' },
        { icon: Landmark, label: 'Manajemen Pajak', href: '/tax-management' },
        { icon: FileCheck, label: 'Pemeriksaan Kas', href: '/cash-audit' },
        { icon: Wallet, label: 'RKAS', href: '/rkas' },
        { icon: FileBarChart, label: 'SPJ / BKU', href: '/spj' },
        { icon: BarChart3, label: 'Kode Anggaran', href: '/kode-label-settings' },
      ]
    },
    {
      label: 'Polling & Billing',
      items: [
        { icon: Vote, label: 'Manajemen Polling', href: '/polling' },
        { icon: Bell, label: 'Billing Dashboard', href: '/billing-dashboard' },
      ]
    },
    {
      label: 'Manajemen Akun',
      items: [
        { icon: UserCheck, label: 'Registrasi Staff', href: '/staff-registration' },
        { icon: GraduationCap, label: 'Registrasi Siswa', href: '/student-registration' },
        { icon: Users, label: 'Akun Staff', href: '/staff-accounts' },
        { icon: Users, label: 'Akun Siswa', href: '/student-accounts' },
      ]
    },
    {
      label: 'Sistem',
      items: [
        { icon: Database, label: 'Backup Database', href: '/database-backup' },
        { icon: FileSpreadsheet, label: 'Edit Data Massal', href: '/bulk-data-editor' },
        { icon: Upload, label: 'Upload Foto Massal', href: '/bulk-photo-upload' },
        { icon: Upload, label: 'Manajemen Upload Berkas', href: '/file-upload-management' },
        { icon: Server, label: 'Sistem Informasi', href: '/system-info' },
        { icon: Settings, label: 'Pengaturan', href: '/settings' },
      ]
    },
  ];

  const toggleGroup = (label: string) => {
    setOpenGroups(prev => ({ ...prev, [label]: !prev[label] }));
  };

  const baseTeacherMenuItems: MenuItem[] = [
    { icon: Users, label: 'Dashboard', href: '/' },
    { icon: Calendar, label: 'Jadwal', href: '/schedules' },
    { icon: ClipboardList, label: 'Absensi', href: '/attendance' },
    { icon: FileText, label: 'Jurnal Mengajar', href: '/journals' },
    { icon: GraduationCap, label: 'Nilai', href: '/grades' },
    { icon: TrendingUp, label: 'Analytics Nilai', href: '/grade-analytics' },
    { icon: FileText, label: 'Rekap Absensi Siswa', href: '/student-attendance-report' },
    { icon: AlertTriangle, label: 'Poin Pelanggaran', href: '/violations' },
    { icon: FileText, label: 'Catatan Kejadian Penting', href: '/important-event-notes' },
    { icon: FileCheck, label: 'Ujian CBT', href: '/cbt-management' },
    { icon: FolderOpen, label: 'Repositori', href: '/repository' },
    { icon: Settings, label: 'Pengaturan', href: '/settings' },
  ];

  const homeroomMenuItem = { icon: UserCheck, label: 'Rekap Absen Wali Kelas', href: '/homeroom-attendance' };
  
  const teacherMenuItems = isHomeroomTeacher 
    ? [...baseTeacherMenuItems.slice(0, 4), homeroomMenuItem, ...baseTeacherMenuItems.slice(4)]
    : baseTeacherMenuItems;

  const bendaharaMenuItems = [
    { icon: Users, label: 'Dashboard', href: '/bendahara-dashboard' },
    { icon: FileSignature, label: 'Surat Tugas', href: '/assignment-letters' },
    { icon: Plane, label: 'SPPD', href: '/official-travel' },
    { icon: Receipt, label: 'Kwitansi', href: '/payment-receipts' },
    { icon: Hammer, label: 'Upah Tukang', href: '/worker-payments' },
    { icon: GraduationCap, label: 'Honorarium GTT/PTT', href: '/gtt-ptt-honorarium' },
    { icon: Award, label: 'Honorarium Ekskul', href: '/extracurricular-honorarium' },
    { icon: Receipt, label: 'Kwitansi Narasumber', href: '/narasumber-honorarium' },
    { icon: Landmark, label: 'Manajemen Pajak', href: '/tax-management' },
    { icon: FileCheck, label: 'Pemeriksaan Kas', href: '/cash-audit' },
    { icon: Wallet, label: 'RKAS', href: '/rkas' },
    { icon: FileBarChart, label: 'SPJ / BKU', href: '/spj' },
    { icon: BarChart3, label: 'Kode Anggaran', href: '/kode-label-settings' },
    { icon: Settings, label: 'Pengaturan Bendahara', href: '/bendahara-settings' },
  ];

  // Tata Usaha has access to Surat Tugas, SPPD, Kwitansi, and Surat Masuk/Keluar
  const tataUsahaMenuItems = [
    { icon: Users, label: 'Dashboard', href: '/tata-usaha-dashboard' },
    { icon: FileSignature, label: 'Surat Tugas', href: '/assignment-letters' },
    { icon: Plane, label: 'SPPD', href: '/official-travel' },
    { icon: Receipt, label: 'Kwitansi', href: '/payment-receipts' },
    { icon: Inbox, label: 'Surat Masuk', href: '/surat-masuk' },
    { icon: Send, label: 'Surat Keluar', href: '/surat-keluar' },
  ];

  // Kesiswaan menu items
  const kesiswaanMenuItems = [
    { icon: Users, label: 'Dashboard', href: '/kesiswaan-dashboard' },
    { icon: ClipboardList, label: 'Absensi', href: '/attendance' },
    { icon: AlertTriangle, label: 'Poin Pelanggaran', href: '/violations' },
    { icon: Award, label: 'Penghargaan & Prestasi', href: '/achievements' },
    { icon: Settings, label: 'Pengaturan', href: '/settings' },
  ];

  // Guru Piket menu items - with attendance button
  const guruPiketMenuItems = [
    { icon: Users, label: 'Dashboard', href: '/guru-piket-dashboard' },
    { icon: ClipboardList, label: 'Isi Absensi', href: '/attendance' },
    { icon: FileText, label: 'Dispensasi Siswa', href: '/dispensasi-siswa' },
    { icon: BookOpen, label: 'Buku Tamu', href: '/buku-tamu' },
    { icon: Settings, label: 'Pengaturan', href: '/settings' },
  ];

  // Siswa menu items
  const siswaMenuItems = [
    { icon: Users, label: 'Dashboard', href: '/student-dashboard' },
    { icon: BookOpen, label: 'Jadwal Hari Ini', href: '/student-dashboard?tab=schedule' },
    { icon: TrendingUp, label: 'Nilai Akademik', href: '/student-dashboard?tab=grades' },
    { icon: ClipboardList, label: 'Kehadiran', href: '/student-dashboard?tab=attendance' },
    { icon: AlertTriangle, label: 'Pelanggaran', href: '/student-dashboard?tab=violations' },
    { icon: Award, label: 'Prestasi', href: '/student-dashboard?tab=achievements' },
    { icon: Megaphone, label: 'Pengumuman', href: '/student-dashboard?tab=announcements' },
    { icon: FileText, label: 'Riwayat Dispensasi', href: '/student-dashboard?tab=dispensasi' },
    { icon: FileCheck, label: 'Ujian CBT', href: '/cbt-student' },
  ];

  // Polling menu items
  const pollingMenuItems = [
    { icon: Vote, label: 'Manajemen Polling', href: '/polling' },
    { icon: UserCircle, label: 'Data Guru', href: '/teachers' },
  ];

  // Billing menu items
  const billingMenuItems = [
    { icon: Bell, label: 'Notifikasi Popup', href: '/billing-dashboard' },
    { icon: Lock, label: 'Penguncian Akun', href: '/billing-dashboard' },
  ];

  // Super Admin menu items
  const superAdminMenuItems = [
    { icon: Users, label: 'Dashboard', href: '/super-admin' },
    { icon: Database, label: 'Backup Database', href: '/database-backup' },
    { icon: Settings, label: 'Pengaturan', href: '/settings' },
  ];

  // Menu items for non-admin roles (flat structure)
  const menuItems: MenuItem[] = userRole === 'super_admin'
    ? superAdminMenuItems
    : userRole === 'bendahara' 
      ? bendaharaMenuItems 
      : userRole === 'tata_usaha'
        ? tataUsahaMenuItems
        : userRole === 'kesiswaan'
          ? kesiswaanMenuItems
          : userRole === 'guru_piket'
            ? guruPiketMenuItems
            : userRole === 'siswa'
              ? siswaMenuItems
              : userRole === 'polling'
                ? pollingMenuItems
                : userRole === 'billing'
                  ? billingMenuItems
                  : teacherMenuItems;

  // Helper function to render a single menu item
  const renderMenuItem = (menuItem: MenuItem, forceExpanded = false) => {
    const Icon = menuItem.icon;
    const isActive = location.pathname === menuItem.href;
    
    const menuButton = (
      <Button
        variant={isActive ? 'secondary' : 'ghost'}
        className={cn(
          'w-full transition-all duration-300 h-9 hover:scale-105',
          isCollapsed && !forceExpanded ? 'justify-center px-0' : 'justify-start',
          isActive && 'bg-secondary text-secondary-foreground font-medium shadow-sm'
        )}
      >
        <Icon className={cn(
          "h-4 w-4 transition-all duration-300",
          (!isCollapsed || forceExpanded) && "mr-3"
        )} />
        {(!isCollapsed || forceExpanded) && <span className="text-sm animate-fade-in">{menuItem.label}</span>}
      </Button>
    );

    return (
      <div key={menuItem.href}>
        {isCollapsed && !forceExpanded ? (
          <Tooltip>
            <TooltipTrigger asChild>
              <Link to={menuItem.href} onClick={() => setIsMobileMenuOpen(false)}>
                {menuButton}
              </Link>
            </TooltipTrigger>
            <TooltipContent side="right">
              <p>{menuItem.label}</p>
            </TooltipContent>
          </Tooltip>
        ) : (
          <Link to={menuItem.href} onClick={() => setIsMobileMenuOpen(false)}>
            {menuButton}
          </Link>
        )}
      </div>
    );
  };

  return (
    <TooltipProvider delayDuration={0}>
      <div className="flex min-h-screen bg-background">
        {/* Mobile Menu Overlay */}
        {isMobileMenuOpen && (
          <div 
            className="fixed inset-0 z-40 bg-black/50 md:hidden" 
            onClick={() => setIsMobileMenuOpen(false)}
          />
        )}

        {/* Sidebar - Desktop & Mobile */}
        <aside className={cn(
          "fixed inset-y-0 left-0 z-50 border-r bg-card shadow-lg transition-all duration-500 ease-in-out md:relative md:translate-x-0",
          isCollapsed ? "w-16" : "w-64",
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        )}>
          {/* Mobile Close Button */}
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-4 top-4 md:hidden"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <X className="h-5 w-5" />
          </Button>

          {/* Logo & App Name */}
          <div className={cn(
            "flex h-16 items-center border-b transition-all duration-500 ease-in-out",
            isCollapsed ? "justify-center px-2" : "gap-3 px-6"
          )}>
            <div className={cn(
              "flex items-center justify-center rounded-lg bg-primary transition-all duration-500 ease-in-out hover:scale-105",
              isCollapsed ? "h-10 w-10" : "h-10 w-10"
            )}>
              {rightLogoUrl ? (
                <img 
                  src={rightLogoUrl} 
                  alt="Logo" 
                  className="h-8 w-8 object-contain"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                    e.currentTarget.nextElementSibling?.classList.remove('hidden');
                  }}
                />
              ) : null}
              <GraduationCap className={cn(
                "h-6 w-6 text-primary-foreground",
                rightLogoUrl && "hidden"
              )} />
            </div>
            {!isCollapsed && (
              <div className="flex flex-col animate-fade-in">
                <h1 className="text-sm font-semibold text-foreground">
                  {appName}
                </h1>
                <p className="text-xs text-muted-foreground">
                  {userRole === 'admin' ? 'Admin' : userRole === 'super_admin' ? 'Super Admin' : userRole === 'bendahara' ? 'Bendahara' : userRole === 'tata_usaha' ? 'Tata Usaha' : userRole === 'kesiswaan' ? 'Kesiswaan' : userRole === 'guru_piket' ? 'Guru Piket' : userRole === 'siswa' ? 'Siswa' : userRole === 'polling' ? 'Polling' : userRole === 'billing' ? 'Billing' : 'Guru'}
                </p>
              </div>
            )}
          </div>
          
          {/* Collapse Toggle Button - Desktop Only */}
          <div className="hidden md:block absolute -right-4 top-20 z-50">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="icon"
                  className="h-8 w-8 rounded-full bg-primary text-primary-foreground shadow-lg hover:bg-primary/90 hover:scale-110 transition-all duration-300 border-2 border-primary"
                  onClick={() => setIsCollapsed(!isCollapsed)}
                >
                  {isCollapsed ? (
                    <ChevronRight className="h-4 w-4" />
                  ) : (
                    <ChevronLeft className="h-4 w-4" />
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right">
                <p>{isCollapsed ? 'Perluas Menu' : 'Ciutkan Menu'}</p>
              </TooltipContent>
            </Tooltip>
          </div>

          {/* Navigation */}
          <nav className={cn(
            "space-y-1 transition-all duration-500 ease-in-out overflow-y-auto flex-1",
            isCollapsed ? "p-2" : "p-3"
          )}>
            {userRole === 'admin' ? (
              <>
                {/* Dashboard link for admin */}
                {renderMenuItem({ icon: Users, label: 'Dashboard', href: '/' })}
                
                {/* Grouped menu items for admin */}
                {adminMenuGroups.map((group) => {
                  const isOpen = openGroups[group.label] ?? true;
                  const hasActiveItem = group.items.some(item => location.pathname === item.href);
                  
                  if (isCollapsed) {
                    // When collapsed, show separator line and items without group headers
                    return (
                      <div key={group.label}>
                        <div className="my-2 border-t border-border" />
                        {group.items.map((item) => renderMenuItem(item))}
                      </div>
                    );
                  }
                  
                  return (
                    <Collapsible
                      key={group.label}
                      open={isOpen}
                      onOpenChange={() => toggleGroup(group.label)}
                      className="pt-2"
                    >
                      <CollapsibleTrigger asChild>
                        <Button
                          variant="ghost"
                          className={cn(
                            "w-full justify-between px-3 h-8 hover:bg-muted/50",
                            hasActiveItem && "text-primary"
                          )}
                        >
                          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                            {group.label}
                          </span>
                          {isOpen ? (
                            <ChevronUp className="h-3 w-3 text-muted-foreground" />
                          ) : (
                            <ChevronDown className="h-3 w-3 text-muted-foreground" />
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="space-y-1 pt-1">
                        {group.items.map((item) => renderMenuItem(item))}
                      </CollapsibleContent>
                    </Collapsible>
                  );
                })}
              </>
            ) : (
              // Flat menu for other roles
              menuItems.map((item) => renderMenuItem(item))
            )}
          </nav>
        </aside>

        {/* Main Content */}
        <div className="flex flex-1 flex-col min-h-screen">
          {/* Header */}
          <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 px-4 md:px-6">
            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(true)}
            >
              <Menu className="h-5 w-5" />
            </Button>

            {/* User Info */}
            <div className="flex-1 flex items-center gap-3">
              <div className="flex-1">
                <h2 className="text-base font-semibold text-foreground truncate">
                  {profile?.full_name || user?.email}
                </h2>
                <p className="text-xs text-muted-foreground hidden sm:block">
                  {userRole === 'admin' ? 'Administrator' : userRole === 'bendahara' ? 'Bendahara' : userRole === 'tata_usaha' ? 'Tata Usaha' : userRole === 'kesiswaan' ? 'Kesiswaan' : userRole === 'guru_piket' ? 'Guru Piket' : userRole === 'siswa' ? 'Siswa' : 'Guru'}
                </p>
              </div>
            </div>
            
            {/* Actions */}
            <div className="flex items-center gap-2">
              <AcademicYearSelector />
              {userRole === 'teacher' && <NotificationBell />}
              <Button 
                variant="ghost" 
                onClick={signOut} 
                size="sm"
                className="text-muted-foreground hover:text-foreground"
              >
                <LogOut className="mr-2 h-4 w-4" />
                <span className="hidden sm:inline">Logout</span>
              </Button>
            </div>
          </header>

          {/* Page Content */}
          <main className="flex-1 overflow-auto p-4 md:p-6">
            <SubscriptionBanner />
            {children}
          </main>

          {/* Footer */}
          <AppFooter />
        </div>
      </div>
    </TooltipProvider>
  );
};
