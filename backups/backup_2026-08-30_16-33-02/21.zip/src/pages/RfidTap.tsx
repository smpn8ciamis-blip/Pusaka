import { useEffect, useRef, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { motion, AnimatePresence } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { AppFooter } from "@/components/AppFooter";
import {
  CheckCircle2, XCircle, Clock, ScanLine, LogIn, LogOut, AlertTriangle, User,
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface TapStudent {
  id: string;
  full_name: string;
  nis: string | null;
  nisn: string | null;
  photo_url: string | null;
  gender: string | null;
  class_name: string | null;
}

interface TapResult {
  ok: boolean;
  type?: string;
  status?: string;
  time?: string;
  message: string;
  student?: TapStudent;
}

const fmtTime = (d: Date) =>
  d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });
const fmtDate = (d: Date) =>
  d.toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric" });

const RfidTap = () => {
  const [now, setNow] = useState(new Date());
  const [buffer, setBuffer] = useState("");
  const [result, setResult] = useState<TapResult | null>(null);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const clearTimer = useRef<number | null>(null);

  useEffect(() => {
    const t = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(t);
  }, []);

  const { data: branding } = useQuery({
    queryKey: ["rfid-branding"],
    queryFn: async () => {
      const { data } = await supabase.rpc("get_school_settings_for_letterhead");
      return data as any;
    },
    staleTime: 10 * 60 * 1000,
  });

  const { data: settings } = useQuery({
    queryKey: ["rfid-settings-public"],
    queryFn: async () => {
      const { data } = await supabase
        .from("rfid_attendance_settings")
        .select("*")
        .order("created_at")
        .limit(1)
        .maybeSingle();
      return data;
    },
    staleTime: 5 * 60 * 1000,
  });

  const submitUid = useCallback(async (uid: string) => {
    if (!uid.trim() || loading) return;
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("rfid-tap", { body: { uid: uid.trim() } });
      if (error && !data) {
        setResult({ ok: false, message: "Gagal terhubung ke server. Coba lagi." });
      } else {
        setResult(data as TapResult);
      }
    } catch {
      setResult({ ok: false, message: "Terjadi kesalahan. Coba tap ulang kartu." });
    } finally {
      setLoading(false);
      setBuffer("");
      if (clearTimer.current) window.clearTimeout(clearTimer.current);
      clearTimer.current = window.setTimeout(() => setResult(null), 8000);
      inputRef.current?.focus();
    }
  }, [loading]);

  // Keep the hidden input focused so RFID keyboard-emulation readers always work
  useEffect(() => {
    const focus = () => inputRef.current?.focus();
    focus();
    const t = window.setInterval(focus, 1500);
    window.addEventListener("click", focus);
    return () => {
      window.clearInterval(t);
      window.removeEventListener("click", focus);
    };
  }, []);

  const schoolName = branding?.school_name || "Sekolah";
  const logo = branding?.logo_url || branding?.school_logo_url;

  const tone = !result
    ? "idle"
    : result.ok
      ? result.status === "terlambat" && result.type === "check_in" ? "warn" : "success"
      : "error";

  const toneRing: Record<string, string> = {
    idle: "border-primary/20",
    success: "border-emerald-500/50",
    warn: "border-amber-500/50",
    error: "border-destructive/50",
  };

  return (
    <div className="min-h-screen flex flex-col bg-background relative overflow-hidden">
      {/* ambient background */}
      <div className="pointer-events-none absolute inset-0 opacity-60">
        <div className="absolute -top-24 -left-24 h-80 w-80 rounded-full bg-primary/20 blur-3xl" />
        <div className="absolute -bottom-24 -right-24 h-96 w-96 rounded-full bg-emerald-500/10 blur-3xl" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,hsl(var(--border))_1px,transparent_1px),linear-gradient(to_bottom,hsl(var(--border))_1px,transparent_1px)] bg-[size:44px_44px] opacity-[0.15]" />
      </div>

      <input
        ref={inputRef}
        value={buffer}
        onChange={(e) => setBuffer(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            submitUid(buffer);
          }
        }}
        className="absolute opacity-0 h-px w-px -z-10"
        autoComplete="off"
        aria-label="Input kartu RFID"
      />

      <main className="relative flex-1 container mx-auto px-4 py-8 md:py-12">
        {/* Header */}
        <div className="flex flex-col items-center text-center gap-3">
          {logo && (
            <img src={logo} alt={`Logo ${schoolName}`} className="h-16 w-16 md:h-20 md:w-20 object-contain drop-shadow" loading="lazy" />
          )}
          <div>
            <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-primary to-emerald-500 bg-clip-text text-transparent">
              Absensi Kartu RFID
            </h1>
            <p className="text-sm text-muted-foreground mt-1">{schoolName}</p>
          </div>
          <div className="mt-2 rounded-2xl border border-border/60 bg-card/70 backdrop-blur px-6 py-3 shadow-sm">
            <p className="text-4xl md:text-5xl font-mono font-bold tracking-tight tabular-nums">{fmtTime(now)}</p>
            <p className="text-xs md:text-sm text-muted-foreground mt-1">{fmtDate(now)}</p>
          </div>
          {settings && (
            <div className="flex flex-wrap justify-center gap-2 mt-1">
              <Badge variant="outline" className="gap-1">
                <LogIn className="h-3 w-3" /> Masuk {String(settings.check_in_start).slice(0, 5)}–{String(settings.check_in_end).slice(0, 5)}
              </Badge>
              <Badge variant="outline" className="gap-1">
                <LogOut className="h-3 w-3" /> Pulang {String(settings.check_out_start).slice(0, 5)}–{String(settings.check_out_end).slice(0, 5)}
              </Badge>
              <Badge variant="outline" className="gap-1">
                <AlertTriangle className="h-3 w-3" /> Terlambat &gt; {String(settings.late_after).slice(0, 5)}
              </Badge>
            </div>
          )}
        </div>

        {/* Scanner / Result */}
        <div className="mt-8 max-w-2xl mx-auto">
          <AnimatePresence mode="wait">
            {loading ? (
              <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <Card className="border-2 border-primary/30 bg-card/80 backdrop-blur">
                  <CardContent className="py-16 flex flex-col items-center gap-4">
                    <ScanLine className="h-14 w-14 text-primary animate-pulse" />
                    <p className="font-medium">Memproses kartu…</p>
                  </CardContent>
                </Card>
              </motion.div>
            ) : result ? (
              <motion.div
                key={`${result.student?.id ?? "err"}-${result.time ?? ""}`}
                initial={{ opacity: 0, scale: 0.96, y: 12 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.25 }}
              >
                <Card className={`border-2 ${toneRing[tone]} bg-card/85 backdrop-blur shadow-xl`}>
                  <CardContent className="p-6 md:p-8">
                    <div className="flex flex-col sm:flex-row items-center gap-6">
                      <div className="relative">
                        <div className={`h-32 w-32 md:h-40 md:w-40 rounded-2xl overflow-hidden border-2 ${toneRing[tone]} bg-muted flex items-center justify-center`}>
                          {result.student?.photo_url ? (
                            <img src={result.student.photo_url} alt={`Foto ${result.student.full_name}`} className="h-full w-full object-cover" />
                          ) : (
                            <User className="h-14 w-14 text-muted-foreground/50" />
                          )}
                        </div>
                        <div className="absolute -bottom-3 -right-3 rounded-full bg-card p-1 shadow">
                          {tone === "success" ? (
                            <CheckCircle2 className="h-8 w-8 text-emerald-500" />
                          ) : tone === "warn" ? (
                            <AlertTriangle className="h-8 w-8 text-amber-500" />
                          ) : (
                            <XCircle className="h-8 w-8 text-destructive" />
                          )}
                        </div>
                      </div>

                      <div className="flex-1 text-center sm:text-left min-w-0">
                        {result.student ? (
                          <>
                            <h2 className="text-xl md:text-2xl font-bold truncate">{result.student.full_name}</h2>
                            <p className="text-sm text-muted-foreground mt-0.5">
                              {result.student.class_name ? `Kelas ${result.student.class_name} · ` : ""}NIS {result.student.nis ?? "-"}
                            </p>
                          </>
                        ) : (
                          <h2 className="text-xl md:text-2xl font-bold">Kartu Tidak Dikenali</h2>
                        )}

                        <div className="flex flex-wrap justify-center sm:justify-start gap-2 mt-3">
                          {result.type === "check_in" && <Badge className="bg-emerald-500 text-white">Absen Masuk</Badge>}
                          {result.type === "check_out" && <Badge className="bg-sky-500 text-white">Absen Pulang</Badge>}
                          {result.status === "terlambat" && <Badge className="bg-amber-500 text-white">Terlambat</Badge>}
                          {result.time && (
                            <Badge variant="outline" className="gap-1 font-mono">
                              <Clock className="h-3 w-3" /> {result.time}
                            </Badge>
                          )}
                        </div>

                        <p className={`mt-3 text-sm font-medium ${tone === "error" ? "text-destructive" : tone === "warn" ? "text-amber-600 dark:text-amber-400" : "text-emerald-600 dark:text-emerald-400"}`}>
                          {result.message}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ) : (
              <motion.div key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <Card className="border-2 border-dashed border-primary/30 bg-card/60 backdrop-blur">
                  <CardContent className="py-14 flex flex-col items-center gap-5 text-center">
                    <div className="relative">
                      <span className="absolute inset-0 rounded-full bg-primary/20 animate-ping" />
                      <div className="relative h-24 w-24 rounded-full bg-primary/10 flex items-center justify-center">
                        <ScanLine className="h-12 w-12 text-primary" />
                      </div>
                    </div>
                    <div>
                      <p className="text-lg font-semibold">Tempelkan Kartu pada Sensor</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Identitas dan kehadiran akan tercatat otomatis
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>

          <p className="text-center text-xs text-muted-foreground mt-4">
            Layar ini otomatis siap menerima tap berikutnya.
          </p>
        </div>
      </main>

      <AppFooter />
    </div>
  );
};

export default RfidTap;
