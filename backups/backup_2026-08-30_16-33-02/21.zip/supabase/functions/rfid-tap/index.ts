import { createClient } from 'npm:@supabase/supabase-js@2'
import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors'

const TZ_OFFSET_MIN = 7 * 60 // Asia/Jakarta

function jakartaNow() {
  const now = new Date()
  const jakarta = new Date(now.getTime() + TZ_OFFSET_MIN * 60_000)
  const date = jakarta.toISOString().slice(0, 10)
  const minutes = jakarta.getUTCHours() * 60 + jakarta.getUTCMinutes()
  const clock = jakarta.toISOString().slice(11, 19)
  return { now, date, minutes, clock }
}

function toMinutes(t: string | null | undefined) {
  if (!t) return null
  const [h, m] = t.split(':')
  return Number(h) * 60 + Number(m)
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  const json = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), {
      status,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })

  try {
    const body = await req.json().catch(() => ({}))
    const uid = typeof body?.uid === 'string' ? body.uid.trim() : ''
    if (!uid || uid.length > 128) {
      return json({ ok: false, message: 'UID kartu tidak valid' }, 400)
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    )

    const { data: student, error: sErr } = await supabase
      .from('students')
      .select('id, full_name, nis, nisn, photo_url, gender, status, class_id, classes(name)')
      .eq('rfid_uid', uid)
      .maybeSingle()

    if (sErr) throw sErr
    if (!student) return json({ ok: false, message: 'Kartu belum terdaftar. Hubungi admin sekolah.' }, 404)
    if (student.status && student.status !== 'aktif') {
      return json({ ok: false, message: 'Siswa tidak berstatus aktif.' }, 403)
    }

    const { data: settings } = await supabase
      .from('rfid_attendance_settings')
      .select('*')
      .order('created_at')
      .limit(1)
      .maybeSingle()

    if (settings && settings.is_active === false) {
      return json({ ok: false, message: 'Absensi RFID sedang dinonaktifkan.' }, 403)
    }

    const { date, minutes, clock, now } = jakartaNow()
    const inStart = toMinutes(settings?.check_in_start) ?? 6 * 60
    const inEnd = toMinutes(settings?.check_in_end) ?? 7 * 60 + 30
    const lateAfter = toMinutes(settings?.late_after) ?? 7 * 60
    const outStart = toMinutes(settings?.check_out_start) ?? 13 * 60
    const outEnd = toMinutes(settings?.check_out_end) ?? 17 * 60

    const { data: existing } = await supabase
      .from('rfid_attendance')
      .select('*')
      .eq('student_id', student.id)
      .eq('date', date)
      .maybeSingle()

    const profile = {
      id: student.id,
      full_name: student.full_name,
      nis: student.nis,
      nisn: student.nisn,
      photo_url: student.photo_url,
      gender: student.gender,
      class_name: (student as any).classes?.name ?? null,
    }

    // Check-in window
    if (minutes >= inStart && minutes <= inEnd) {
      if (existing?.check_in_at) {
        return json({
          ok: true, type: 'already_in', student: profile, time: clock,
          status: existing.status,
          message: 'Kamu sudah melakukan absen masuk hari ini.',
        })
      }
      const status = minutes > lateAfter ? 'terlambat' : 'hadir'
      const { error } = existing
        ? await supabase.from('rfid_attendance').update({ check_in_at: now.toISOString(), status }).eq('id', existing.id)
        : await supabase.from('rfid_attendance').insert({ student_id: student.id, date, check_in_at: now.toISOString(), status })
      if (error) throw error
      return json({
        ok: true, type: 'check_in', student: profile, time: clock, status,
        message: status === 'terlambat' ? 'Absen masuk tercatat — TERLAMBAT' : 'Absen masuk berhasil. Selamat belajar!',
      })
    }

    // Check-out window
    if (minutes >= outStart && minutes <= outEnd) {
      if (!existing) {
        return json({ ok: false, student: profile, message: 'Belum ada absen masuk hari ini.' }, 409)
      }
      if (existing.check_out_at) {
        return json({
          ok: true, type: 'already_out', student: profile, time: clock,
          status: existing.status, message: 'Kamu sudah melakukan absen pulang hari ini.',
        })
      }
      const { error } = await supabase
        .from('rfid_attendance')
        .update({ check_out_at: now.toISOString() })
        .eq('id', existing.id)
      if (error) throw error
      return json({
        ok: true, type: 'check_out', student: profile, time: clock, status: existing.status,
        message: 'Absen pulang berhasil. Hati-hati di jalan!',
      })
    }

    return json({
      ok: false,
      student: profile,
      time: clock,
      message: 'Di luar jam absensi. Masuk: ' +
        (settings?.check_in_start ?? '06:00').slice(0, 5) + '–' + (settings?.check_in_end ?? '07:30').slice(0, 5) +
        ', Pulang: ' + (settings?.check_out_start ?? '13:00').slice(0, 5) + '–' + (settings?.check_out_end ?? '17:00').slice(0, 5),
    }, 200)
  } catch (e) {
    console.error('rfid-tap error', e)
    return json({ ok: false, message: 'Terjadi kesalahan pada server.' }, 500)
  }
})
